﻿namespace Lab4
{
    partial class CreateStringForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stringText = new System.Windows.Forms.Label();
            this.stringCoordinate = new System.Windows.Forms.Label();
            this.TBStringText = new System.Windows.Forms.TextBox();
            this.TBStringCoordinate = new System.Windows.Forms.TextBox();
            this.createStringBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // stringText
            // 
            this.stringText.AutoSize = true;
            this.stringText.Location = new System.Drawing.Point(262, 84);
            this.stringText.Name = "stringText";
            this.stringText.Size = new System.Drawing.Size(96, 20);
            this.stringText.TabIndex = 0;
            this.stringText.Text = "Текст строки";
            // 
            // stringCoordinate
            // 
            this.stringCoordinate.AutoSize = true;
            this.stringCoordinate.Location = new System.Drawing.Point(262, 161);
            this.stringCoordinate.Name = "stringCoordinate";
            this.stringCoordinate.Size = new System.Drawing.Size(147, 20);
            this.stringCoordinate.TabIndex = 1;
            this.stringCoordinate.Text = "Координаты строки";
            // 
            // TBStringText
            // 
            this.TBStringText.Location = new System.Drawing.Point(262, 107);
            this.TBStringText.Name = "TBStringText";
            this.TBStringText.Size = new System.Drawing.Size(224, 27);
            this.TBStringText.TabIndex = 2;
            // 
            // TBStringCoordinate
            // 
            this.TBStringCoordinate.Location = new System.Drawing.Point(262, 184);
            this.TBStringCoordinate.Name = "TBStringCoordinate";
            this.TBStringCoordinate.Size = new System.Drawing.Size(224, 27);
            this.TBStringCoordinate.TabIndex = 3;
            // 
            // createStringBtn
            // 
            this.createStringBtn.Location = new System.Drawing.Point(262, 231);
            this.createStringBtn.Name = "createStringBtn";
            this.createStringBtn.Size = new System.Drawing.Size(224, 54);
            this.createStringBtn.TabIndex = 4;
            this.createStringBtn.Text = "Создать";
            this.createStringBtn.UseVisualStyleBackColor = true;
            this.createStringBtn.Click += new System.EventHandler(this.createStringBtn_Click);
            // 
            // CreateStringForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.createStringBtn);
            this.Controls.Add(this.TBStringCoordinate);
            this.Controls.Add(this.TBStringText);
            this.Controls.Add(this.stringCoordinate);
            this.Controls.Add(this.stringText);
            this.Name = "CreateStringForm";
            this.Text = "Создание строки";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label stringText;
        private Label stringCoordinate;
        private TextBox TBStringText;
        private TextBox TBStringCoordinate;
        private Button createStringBtn;
    }
}