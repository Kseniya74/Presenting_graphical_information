﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Lab4
{
    public partial class MainForm : Form
    {
        ItemForDrawing object_;
        Bitmap bitmap;
        Brush drawRectBrush;
        Color color;
        int weightOfLine;
        Font font = new Font("Arial", 16);
        public MainForm()
        {
            InitializeComponent();

            bitmap = new Bitmap(pictureBox1.Height, pictureBox1.Width);
            pictureBox1.Image = (Image)bitmap;
            pictureBox1.BackgroundImageLayout = ImageLayout.None;

            drawRectBrush = Brushes.Black;
            color = Color.Black;
            weightOfLine = 10;
            font = new Font("Arial", 16);
        }

        private void updateBitmap()
        {
            if (object_ != null)
            {
                Pen pen = new Pen(drawRectBrush, weightOfLine);

                using (Graphics graph = Graphics.FromImage(bitmap))
                {
                    switch (object_.typeOfObject)
                    {
                        case ((int)ItemForDrawing.TypeOfObject.Point):
                            {
                                bitmap.SetPixel(object_.startCoordinate.X, object_.startCoordinate.Y, color);
                                break;
                            }
                        case ((int)ItemForDrawing.TypeOfObject.Line):
                            {
                                graph.DrawLine(pen, object_.startCoordinate, object_.endCoordinate);   
                                break;
                            }
                        case ((int)ItemForDrawing.TypeOfObject.Rectangle):
                            {
                                Rectangle rect = new Rectangle(object_.startCoordinate, object_.size);
                                graph.DrawRectangle(pen, rect);
                                break;
                            }
                        case ((int)ItemForDrawing.TypeOfObject.Ellipse):
                            {
                                Rectangle rect = new Rectangle(object_.startCoordinate, object_.size);
                                graph.DrawEllipse(pen, rect);
                                break;
                            }
                        case ((int)ItemForDrawing.TypeOfObject.String):
                            {
                                graph.DrawString(object_.text, font, drawRectBrush, object_.startCoordinate);
                                break;
                            }
                    }
                    graph.Flush();
                }
            }
            pictureBox1.Invalidate();
        }

        private void объектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateObjectForm createObjectForm = new CreateObjectForm();

            createObjectForm.ShowDialog();
            object_ = createObjectForm.object_;
            updateBitmap();
        }

        private void строкуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateStringForm createStringForm = new CreateStringForm();

            createStringForm.ShowDialog();
            object_ = createStringForm.object_;
            updateBitmap();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
