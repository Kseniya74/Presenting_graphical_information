﻿namespace Lab4
{
    partial class CreateObjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.objType = new System.Windows.Forms.Label();
            this.CBObjType = new System.Windows.Forms.ComboBox();
            this.objCoordinates = new System.Windows.Forms.Label();
            this.TBObjCoordinates = new System.Windows.Forms.TextBox();
            this.objSize = new System.Windows.Forms.Label();
            this.TBObjSize = new System.Windows.Forms.TextBox();
            this.createObjBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // objType
            // 
            this.objType.AutoSize = true;
            this.objType.Location = new System.Drawing.Point(329, 72);
            this.objType.Name = "objType";
            this.objType.Size = new System.Drawing.Size(95, 20);
            this.objType.TabIndex = 0;
            this.objType.Text = "Тип объекта";
            // 
            // CBObjType
            // 
            this.CBObjType.FormattingEnabled = true;
            this.CBObjType.Location = new System.Drawing.Point(273, 95);
            this.CBObjType.Name = "CBObjType";
            this.CBObjType.Size = new System.Drawing.Size(211, 28);
            this.CBObjType.TabIndex = 1;
            this.CBObjType.SelectedIndexChanged += new System.EventHandler(this.CBObjType_SelectedIndexChanged);
            // 
            // objCoordinates
            // 
            this.objCoordinates.AutoSize = true;
            this.objCoordinates.Location = new System.Drawing.Point(300, 146);
            this.objCoordinates.Name = "objCoordinates";
            this.objCoordinates.Size = new System.Drawing.Size(156, 20);
            this.objCoordinates.TabIndex = 2;
            this.objCoordinates.Text = "Координаты объекта";
            // 
            // TBObjCoordinates
            // 
            this.TBObjCoordinates.Location = new System.Drawing.Point(275, 169);
            this.TBObjCoordinates.Name = "TBObjCoordinates";
            this.TBObjCoordinates.Size = new System.Drawing.Size(209, 27);
            this.TBObjCoordinates.TabIndex = 3;
            // 
            // objSize
            // 
            this.objSize.AutoSize = true;
            this.objSize.Location = new System.Drawing.Point(310, 217);
            this.objSize.Name = "objSize";
            this.objSize.Size = new System.Drawing.Size(131, 20);
            this.objSize.TabIndex = 4;
            this.objSize.Text = "Размеры объекта";
            // 
            // TBObjSize
            // 
            this.TBObjSize.Location = new System.Drawing.Point(273, 240);
            this.TBObjSize.Name = "TBObjSize";
            this.TBObjSize.Size = new System.Drawing.Size(211, 27);
            this.TBObjSize.TabIndex = 5;
            // 
            // createObjBtn
            // 
            this.createObjBtn.Location = new System.Drawing.Point(273, 300);
            this.createObjBtn.Name = "createObjBtn";
            this.createObjBtn.Size = new System.Drawing.Size(211, 44);
            this.createObjBtn.TabIndex = 6;
            this.createObjBtn.Text = "Создать";
            this.createObjBtn.UseVisualStyleBackColor = true;
            this.createObjBtn.Click += new System.EventHandler(this.createObjBtn_Click);
            // 
            // CreateObjectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.createObjBtn);
            this.Controls.Add(this.TBObjSize);
            this.Controls.Add(this.objSize);
            this.Controls.Add(this.TBObjCoordinates);
            this.Controls.Add(this.objCoordinates);
            this.Controls.Add(this.CBObjType);
            this.Controls.Add(this.objType);
            this.Name = "CreateObjectForm";
            this.Text = "Создание объекта";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label objType;
        private ComboBox CBObjType;
        private Label objCoordinates;
        private TextBox TBObjCoordinates;
        private Label objSize;
        private TextBox TBObjSize;
        private Button createObjBtn;
    }
}