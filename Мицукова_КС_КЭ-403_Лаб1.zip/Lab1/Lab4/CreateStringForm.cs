﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class CreateStringForm : Form
    {
        public ItemForDrawing object_;
        public CreateStringForm()
        {
            InitializeComponent();
        }

        private void createStringBtn_Click(object sender, EventArgs e)
        {
            if (!checkInputFields())
                return;

            Point coordinate = convertStringToPoint(TBStringCoordinate.Text);
            string text = TBStringText.Text;
            object_ = new ItemForDrawing(coordinate, text);

            this.Close();
        }

        private Point convertStringToPoint(string data)
        {
            int[] coord = Array.ConvertAll(data.Trim().Split(";"), int.Parse);

            return new Point(coord[0], coord[1]);
        }

        private bool checkInputFields()
        {
            string coordinate = TBStringCoordinate.Text;
            string text = TBStringText.Text;

            if (coordinate == "")
            {
                MessageBox.Show("Введите координаты строки", "Ошибка");
                return false;
            }
            else if (text == "")
            {
                MessageBox.Show("Введите текст строки", "Ошибка");
                return false;
            }

            return true;
        }
    }
}
