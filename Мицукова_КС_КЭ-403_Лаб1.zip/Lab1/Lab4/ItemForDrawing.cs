﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    public class ItemForDrawing
    {
        public enum TypeOfObject : int
        { Point = 0, Line = 1, Rectangle = 2, Ellipse = 3, String = 4}
        public Point startCoordinate { get; set; }
        public Point endCoordinate { get; set; }
        public Size size { get; set; }
        public String text { get; set; }
        public int typeOfObject { get; set; }

        public ItemForDrawing(Point coordinate)
        {
            startCoordinate = coordinate;
            this.typeOfObject = (int)TypeOfObject.Point;
        }

        public ItemForDrawing(int typeOfObject, Point coordinate, Size size)
        {
            this.startCoordinate = coordinate;
            this.size = size;
            this.typeOfObject = typeOfObject;
        }

        public ItemForDrawing(Point startCoordinate, Point endCoordinate)
        {
            this.startCoordinate = startCoordinate;
            this.endCoordinate = endCoordinate;
            this.typeOfObject = (int)TypeOfObject.Line;
        }

        public ItemForDrawing(Point startCoordinate, String text)
        {
            this.text = text;
            this.startCoordinate = startCoordinate;
            this.typeOfObject = (int)TypeOfObject.String;
        }
    }
}
