﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class CreateObjectForm : Form
    {
        public ItemForDrawing object_;
        public CreateObjectForm()
        {
            InitializeComponent();

            var items = new string[] { "Точка", "Линия", "Прямоугольник", "Эллипс" };
            CBObjType.Items.AddRange(items);
        }

        private void createObjBtn_Click(object sender, EventArgs e)
        {
            if (!checkInputFields())
                return;

            int typeOfObject = CBObjType.SelectedIndex;
            string coordinate = TBObjCoordinates.Text;
            string size_ = TBObjSize.Text;

            Point startCoordinate, endCoordinate;

            switch (typeOfObject)
            {
                case (int)ItemForDrawing.TypeOfObject.Point:
                    {
                        startCoordinate = convertStringToPoint(coordinate);
                        break;
                    }
                case (int)ItemForDrawing.TypeOfObject.Line:
                    {
                        string[] coord = coordinate.Split(" ");
                        startCoordinate = convertStringToPoint(coord[0]);
                        endCoordinate = convertStringToPoint(coord[1]);
                        object_ = new ItemForDrawing(startCoordinate, endCoordinate);
                        break;
                    }
                case (int)ItemForDrawing.TypeOfObject.Rectangle:
                case (int)ItemForDrawing.TypeOfObject.Ellipse:
                    {
                        startCoordinate = convertStringToPoint(coordinate);
                        Size size = convertStringToSize(size_);
                        object_ = new ItemForDrawing(typeOfObject, startCoordinate, size);
                        break;
                    }
                default:
                    break;
            }
            this.Close();
        }

        private bool checkInputFields()
        {
            int typeOfObject = CBObjType.SelectedIndex;
            string coordinate = TBObjCoordinates.Text;
            string size_ = TBObjSize.Text;

            if (typeOfObject == -1)
            {
                MessageBox.Show("Выберите тип объекта", "Ошибка");
                return false;
            }
            else
                if(coordinate == "")
            {
                MessageBox.Show("Введите координаты объекта", "Ошибка");
                return false;
            }
            else if (typeOfObject > 1 && size_ == "")
            {
                MessageBox.Show("Введите размеры объекта", "Ошибка");
                return false;
            }

            return true;
        }

        private Point convertStringToPoint(string data)
        {
            int[] coord = Array.ConvertAll(data.Trim().Split(";"), int.Parse);

            return new Point(coord[0], coord[1]);
        }

        private Size convertStringToSize(string size)
        {
            int[] data = Array.ConvertAll(size.Trim().Split(";"), int.Parse);

            return new Size(data[0], data[1]);
        }

        private void CBObjType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (CBObjType.SelectedIndex)
            {
                case (int)ItemForDrawing.TypeOfObject.Point:
                case (int)ItemForDrawing.TypeOfObject.Line:
                    {
                        TBObjSize.Visible = false;
                        objSize.Visible = false;
                        break;
                    }
                case (int)ItemForDrawing.TypeOfObject.Ellipse:
                case (int)ItemForDrawing.TypeOfObject.Rectangle:
                    {
                        TBObjSize.Visible = true;
                        objSize.Visible = true;
                        break;
                    }
                default:
                    break;
            }
               
        }
    }
}
