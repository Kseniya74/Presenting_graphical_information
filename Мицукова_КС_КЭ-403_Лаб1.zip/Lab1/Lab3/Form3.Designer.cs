﻿namespace Lab3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.типЛинииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.непрерывнаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пунктирнаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.толщинаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.цветФонаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.цветЛинииОбводкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CDBrush = new System.Windows.Forms.ColorDialog();
            this.CDPen = new System.Windows.Forms.ColorDialog();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.типЛинииToolStripMenuItem,
            this.толщинаToolStripMenuItem,
            this.цветФонаToolStripMenuItem,
            this.цветЛинииОбводкиToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(223, 100);
            // 
            // типЛинииToolStripMenuItem
            // 
            this.типЛинииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.непрерывнаяToolStripMenuItem,
            this.пунктирнаяToolStripMenuItem});
            this.типЛинииToolStripMenuItem.Name = "типЛинииToolStripMenuItem";
            this.типЛинииToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.типЛинииToolStripMenuItem.Text = "Тип линии";
            // 
            // непрерывнаяToolStripMenuItem
            // 
            this.непрерывнаяToolStripMenuItem.Name = "непрерывнаяToolStripMenuItem";
            this.непрерывнаяToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.непрерывнаяToolStripMenuItem.Text = "Непрерывная";
            this.непрерывнаяToolStripMenuItem.Click += new System.EventHandler(this.непрерывнаяToolStripMenuItem_Click);
            // 
            // пунктирнаяToolStripMenuItem
            // 
            this.пунктирнаяToolStripMenuItem.Name = "пунктирнаяToolStripMenuItem";
            this.пунктирнаяToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.пунктирнаяToolStripMenuItem.Text = "Пунктирная";
            this.пунктирнаяToolStripMenuItem.Click += new System.EventHandler(this.пунктирнаяToolStripMenuItem_Click);
            // 
            // толщинаToolStripMenuItem
            // 
            this.толщинаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.толщинаToolStripMenuItem.Name = "толщинаToolStripMenuItem";
            this.толщинаToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.толщинаToolStripMenuItem.Text = "Толщина";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(108, 26);
            this.toolStripMenuItem2.Text = "5";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(108, 26);
            this.toolStripMenuItem3.Text = "10";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(108, 26);
            this.toolStripMenuItem4.Text = "15";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // цветФонаToolStripMenuItem
            // 
            this.цветФонаToolStripMenuItem.Name = "цветФонаToolStripMenuItem";
            this.цветФонаToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.цветФонаToolStripMenuItem.Text = "Цвет фона";
            this.цветФонаToolStripMenuItem.Click += new System.EventHandler(this.цветФонаToolStripMenuItem_Click);
            // 
            // цветЛинииОбводкиToolStripMenuItem
            // 
            this.цветЛинииОбводкиToolStripMenuItem.Name = "цветЛинииОбводкиToolStripMenuItem";
            this.цветЛинииОбводкиToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.цветЛинииОбводкиToolStripMenuItem.Text = "Цвет линии обводки";
            this.цветЛинииОбводкиToolStripMenuItem.Click += new System.EventHandler(this.цветЛинииОбводкиToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(-2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(804, 452);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseClick);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Лабораторная работа №3";
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ContextMenuStrip contextMenuStrip;
        private ToolStripMenuItem типЛинииToolStripMenuItem;
        private ToolStripMenuItem непрерывнаяToolStripMenuItem;
        private ToolStripMenuItem пунктирнаяToolStripMenuItem;
        private ToolStripMenuItem толщинаToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem цветФонаToolStripMenuItem;
        private ToolStripMenuItem цветЛинииОбводкиToolStripMenuItem;
        private Panel panel1;
        private ColorDialog CDBrush;
        private ColorDialog CDPen;
    }
}