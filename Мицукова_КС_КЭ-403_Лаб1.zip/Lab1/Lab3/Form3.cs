﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Lab3
{
    public partial class Form3 : Form
    {
        enum WeightOfLine : int { Five = 5, Ten = 10, Fifteen = 15};
        DashStyle typeOfLine;
        int weightOfLine;
        Point startCoordinates;
        Point previousCoordinates;
        Size sizeObj;
        bool moveObj;
        Color colorBrush;
        Color colorPen;
        Pen pen;
        Brush brush;

        public Form3()
        {
            InitializeComponent();

            weightOfLine = (int)WeightOfLine.Five;

            startCoordinates = new Point(50, 50);
            sizeObj = new Size(100, 100);
            moveObj = false;
            previousCoordinates = startCoordinates;

            colorBrush = Color.AliceBlue;
            colorPen = Color.Black;

            pen = new Pen(colorPen, (int)weightOfLine);
            brush = new SolidBrush(colorBrush);
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                contextMenuStrip.Show(PointToScreen(e.Location));
        }

        private void непрерывнаяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            typeOfLine = DashStyle.Solid;
            panel1.Refresh();
        }

        private void пунктирнаяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            typeOfLine = DashStyle.Dot;
            panel1.Refresh();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            weightOfLine = (int)WeightOfLine.Five;
            panel1.Refresh();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            weightOfLine = (int)WeightOfLine.Ten;
            panel1.Refresh();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            weightOfLine = (int)WeightOfLine.Fifteen;
            panel1.Refresh();
        }

        private void цветФонаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (CDBrush.ShowDialog() == DialogResult.OK)
            {
                colorBrush = CDBrush.Color;
                panel1.Refresh();
            }
        }

        private void цветЛинииОбводкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (CDPen.ShowDialog() == DialogResult.OK)
            {
                colorPen = CDPen.Color;
                panel1.Refresh();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics graph = e.Graphics;
            Rectangle rect = new Rectangle(startCoordinates, sizeObj);

            brush = new SolidBrush(colorBrush);
            pen = new Pen(colorPen)
            {
                Width = weightOfLine,
                DashStyle = typeOfLine
            };

            graph.FillRectangle(brush, rect);
            graph.DrawRectangle(pen, rect);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            moveObj = true;
            previousCoordinates = e.Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (moveObj)
            {
                startCoordinates.X = previousCoordinates.X + (previousCoordinates.X - e.Location.X);
                startCoordinates.Y = previousCoordinates.Y + (previousCoordinates.Y - e.Location.Y);
                panel1.Refresh();
                previousCoordinates = e.Location;
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            moveObj = false;
        }
    }
}
