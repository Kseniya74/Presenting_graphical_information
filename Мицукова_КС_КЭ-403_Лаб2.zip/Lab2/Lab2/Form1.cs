namespace Lab2
{
    public partial class Form1 : Form
    {
        Graphics graphics;
        Bitmap bitmap;
        public double angle, kf1, kf2, dx, dy;
        private PointF[] initialPoints;
        private PointF[] currentPoints;
        Pen pen = new Pen(Color.Black, 2);

        public Form1()
        {
            InitializeComponent();
            bitmap = new Bitmap(PBFigure.Width, PBFigure.Height);
            PBFigure.Image = (Image)bitmap;
            PBFigure.BackgroundImageLayout = ImageLayout.None;

            initialPoints = new PointF[5]
            {
                new Point(220, 135),
                new Point(235, 160),
                new Point(249, 150),
                new Point(290, 210),
                new Point(125, 210)
            };
            currentPoints = (PointF[])initialPoints.Clone();
        }

        /*
         * ��������� ������ �� ����� �� ��������������� ������
         */
        private void createObjBtn_Click(object sender, EventArgs e)
        {
            refresh();
            graphics = PBFigure.CreateGraphics();
            graphics.DrawLine(pen, initialPoints[0].X, initialPoints[0].Y, initialPoints[1].X, initialPoints[1].Y);
            graphics.DrawLine(pen, initialPoints[1].X, initialPoints[1].Y, initialPoints[2].X, initialPoints[2].Y);
            graphics.DrawLine(pen, initialPoints[2].X, initialPoints[2].Y, initialPoints[3].X, initialPoints[3].Y);
            graphics.DrawLine(pen, initialPoints[3].X, initialPoints[3].Y, initialPoints[4].X, initialPoints[4].Y);
            graphics.DrawLine(pen, initialPoints[4].X, initialPoints[4].Y, initialPoints[0].X, initialPoints[0].Y);
        }

        /*
         * �������� ������ �� ����� �� ��������������� ������
         */
        private void turnObjBtn_Click(object sender, EventArgs e)
        {
            refresh();

            if (TBMoveObjX.Text != "" && TBMoveObjY.Text != "")
            { 
                float dx = float.Parse(TBMoveObjX.Text);
                float dy = float.Parse(TBMoveObjY.Text);
                PointF[] temp = new PointF[currentPoints.Length];
                for (int i = 0; i < currentPoints.Length; i++)
                {
                    float x = currentPoints[i].X + dx;
                    float y = currentPoints[i].Y + dy;
                    temp[i] = new PointF(x, y);
                }

                currentPoints = temp;
                paint();
            }
            else if (TBMoveObjX.Text != "" && TBMoveObjY.Text == "")
            {
                float dx = (float)Convert.ToDouble(TBMoveObjX.Text);
                float dy = 0;
                PointF[] temp = new PointF[currentPoints.Length];
                for (int i = 0; i < currentPoints.Length; i++)
                {
                    float x = currentPoints[i].X + dx;
                    float y = currentPoints[i].Y + dy;
                    temp[i] = new PointF(x, y);
                }

                currentPoints = temp;
                paint();
            }
            else if (TBMoveObjX.Text == "" && TBMoveObjY.Text != "")
            {
                float dx = 0;
                float dy = (float)Convert.ToDouble(TBMoveObjY.Text);
                PointF[] temp = new PointF[currentPoints.Length];
                for (int i = 0; i < currentPoints.Length; i++)
                {
                    float x = currentPoints[i].X + dx;
                    float y = currentPoints[i].Y + dy;
                    temp[i] = new PointF(x, y);
                }

                currentPoints = temp;
                paint();
            }
            else
            {
                MessageBox.Show("������� ����������", "������");
            }
        }


        /*
        * ������� ������ �� ����� �� ��������������� ������
        */
        private void turnBtn_Click(object sender, EventArgs e)
        {
            PointF r = currentPoints[0];
            refresh();
            if (TBAngleTurn.Text != "")
            {
                angle = Convert.ToDouble(TBAngleTurn.Text) * Math.PI / 180;
                PointF[] temp = new PointF[currentPoints.Length];
                
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = r.X + (float)(currentPoints[j].X * Math.Cos(angle) - currentPoints[j].Y * Math.Sin(angle) - (r.X * Math.Cos(angle) - r.Y * Math.Sin(angle)));
                    float y = r.Y + (float)(currentPoints[j].X * Math.Sin(angle) + currentPoints[j].Y * Math.Cos(angle) - (r.X * Math.Sin(angle) + r.Y * Math.Cos(angle)));
                    temp[j] = new PointF(x, y);
                }
                currentPoints = temp;
                paint();
            }
            else
            {
                MessageBox.Show("������� ������ ��������", "������");
            }
        }

        /*
         * ������/���������� ������ �� ����� �� ��������������� ������
         */
        private void sizeBtn_Click(object sender, EventArgs e)
        {
            refresh();
            if (TBSizeX.Text != "" && TBSizeY.Text != "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = (float)Convert.ToDouble(TBSizeX.Text);
                float kf2 = (float)Convert.ToDouble(TBSizeY.Text);
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X * kf1;
                    float y = currentPoints[j].Y * kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else if (TBSizeX.Text == "" && TBSizeY.Text != "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = 1;
                float kf2 = (float)Convert.ToDouble(TBSizeY.Text);
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X * kf1;
                    float y = currentPoints[j].Y * kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else if (TBSizeX.Text != "" && TBSizeY.Text == "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = (float)Convert.ToDouble(TBSizeX.Text);
                float kf2 = 1;
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X * kf1;
                    float y = currentPoints[j].Y * kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else
            {
                MessageBox.Show("������� ����������", "������");
            }
        }


        private void decSizeObjBtn_Click(object sender, EventArgs e)
        {
            refresh();
            if (TBSizeX.Text != "" && TBSizeY.Text != "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = (float)Convert.ToDouble(TBSizeX.Text);
                float kf2 = (float)Convert.ToDouble(TBSizeY.Text);
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X / kf1;
                    float y = currentPoints[j].Y / kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else if (TBSizeX.Text == "" && TBSizeY.Text != "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = 1;
                float kf2 = (float)Convert.ToDouble(TBSizeY.Text);
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X / kf1;
                    float y = currentPoints[j].Y / kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else if (TBSizeX.Text != "" && TBSizeY.Text == "")
            {
                PointF[] temp = new PointF[currentPoints.Length];
                float kf1 = (float)Convert.ToDouble(TBSizeX.Text);
                float kf2 = 1;
                float x_ = 0;
                float y_ = 0;
                for (int j = 0; j < currentPoints.Length; j++)
                {
                    float x = currentPoints[j].X / kf1;
                    float y = currentPoints[j].Y / kf2;
                    if (j == 0)
                    {
                        x_ = currentPoints[j].X - x;
                        y_ = currentPoints[j].Y - y;
                    }
                    temp[j] = new PointF(x + x_, y + y_);
                }
                currentPoints = temp;
                paint();
            }
            else
            {
                MessageBox.Show("������� ����������", "������");
            }
        }

        /*
         * ���������� (���������) ������
         */
        private void refresh()
        {
            Graphics g = Graphics.FromImage(bitmap);
            g.Clear(PBFigure.BackColor);
            PBFigure.Image = bitmap;
            PBFigure.Refresh();
            g.Dispose();
        }

        /*
         * ��������� ���������� ������
         */
        private void paint()
        {
            Graphics graphics = PBFigure.CreateGraphics();
            graphics.Clear(ColorTranslator.FromHtml("#F0F0F0"));
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.DrawLine(pen, (float)currentPoints[0].X, (float)currentPoints[0].Y, (float)currentPoints[1].X, (float)currentPoints[1].Y);
                g.DrawLine(pen, (float)currentPoints[1].X, (float)currentPoints[1].Y, (float)currentPoints[2].X, (float)currentPoints[2].Y);
                g.DrawLine(pen, (float)currentPoints[2].X, (float)currentPoints[2].Y, (float)currentPoints[3].X, (float)currentPoints[3].Y);
                g.DrawLine(pen, (float)currentPoints[3].X, (float)currentPoints[3].Y, (float)currentPoints[4].X, (float)currentPoints[4].Y);
                g.DrawLine(pen, (float)currentPoints[4].X, (float)currentPoints[4].Y, (float)currentPoints[0].X, (float)currentPoints[0].Y);
            }
            PBFigure.Invalidate();
        }
    }
}