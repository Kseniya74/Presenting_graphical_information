﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBMenu = new System.Windows.Forms.GroupBox();
            this.decSizeObjBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.createObjBtn = new System.Windows.Forms.Button();
            this.sizeBtn = new System.Windows.Forms.Button();
            this.TBSizeY = new System.Windows.Forms.TextBox();
            this.TBSizeX = new System.Windows.Forms.TextBox();
            this.labelSize = new System.Windows.Forms.Label();
            this.turnBtn = new System.Windows.Forms.Button();
            this.TBAngleTurn = new System.Windows.Forms.TextBox();
            this.labelTurnObj = new System.Windows.Forms.Label();
            this.turnObjBtn = new System.Windows.Forms.Button();
            this.TBMoveObjY = new System.Windows.Forms.TextBox();
            this.TBMoveObjX = new System.Windows.Forms.TextBox();
            this.labelMoveObj = new System.Windows.Forms.Label();
            this.PBFigure = new System.Windows.Forms.PictureBox();
            this.GBMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBFigure)).BeginInit();
            this.SuspendLayout();
            // 
            // GBMenu
            // 
            this.GBMenu.Controls.Add(this.decSizeObjBtn);
            this.GBMenu.Controls.Add(this.label5);
            this.GBMenu.Controls.Add(this.label4);
            this.GBMenu.Controls.Add(this.label3);
            this.GBMenu.Controls.Add(this.label2);
            this.GBMenu.Controls.Add(this.label1);
            this.GBMenu.Controls.Add(this.createObjBtn);
            this.GBMenu.Controls.Add(this.sizeBtn);
            this.GBMenu.Controls.Add(this.TBSizeY);
            this.GBMenu.Controls.Add(this.TBSizeX);
            this.GBMenu.Controls.Add(this.labelSize);
            this.GBMenu.Controls.Add(this.turnBtn);
            this.GBMenu.Controls.Add(this.TBAngleTurn);
            this.GBMenu.Controls.Add(this.labelTurnObj);
            this.GBMenu.Controls.Add(this.turnObjBtn);
            this.GBMenu.Controls.Add(this.TBMoveObjY);
            this.GBMenu.Controls.Add(this.TBMoveObjX);
            this.GBMenu.Controls.Add(this.labelMoveObj);
            this.GBMenu.Location = new System.Drawing.Point(1, 1);
            this.GBMenu.Name = "GBMenu";
            this.GBMenu.Size = new System.Drawing.Size(340, 792);
            this.GBMenu.TabIndex = 0;
            this.GBMenu.TabStop = false;
            // 
            // decSizeObjBtn
            // 
            this.decSizeObjBtn.Location = new System.Drawing.Point(13, 711);
            this.decSizeObjBtn.Name = "decSizeObjBtn";
            this.decSizeObjBtn.Size = new System.Drawing.Size(140, 59);
            this.decSizeObjBtn.TabIndex = 17;
            this.decSizeObjBtn.Text = "Сжать фигуру";
            this.decSizeObjBtn.UseVisualStyleBackColor = true;
            this.decSizeObjBtn.Click += new System.EventHandler(this.decSizeObjBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(33, 670);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 22);
            this.label5.TabIndex = 16;
            this.label5.Text = "Введите Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(33, 626);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 22);
            this.label4.TabIndex = 15;
            this.label4.Text = "Введите Х";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(13, 416);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 22);
            this.label3.TabIndex = 14;
            this.label3.Text = "Введите угол";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(33, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 22);
            this.label2.TabIndex = 13;
            this.label2.Text = "Введите Y";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(33, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 22);
            this.label1.TabIndex = 12;
            this.label1.Text = "Введите Х";
            // 
            // createObjBtn
            // 
            this.createObjBtn.Location = new System.Drawing.Point(64, 26);
            this.createObjBtn.Name = "createObjBtn";
            this.createObjBtn.Size = new System.Drawing.Size(191, 57);
            this.createObjBtn.TabIndex = 11;
            this.createObjBtn.Text = "Создать фигуру";
            this.createObjBtn.UseVisualStyleBackColor = true;
            this.createObjBtn.Click += new System.EventHandler(this.createObjBtn_Click);
            // 
            // sizeBtn
            // 
            this.sizeBtn.Location = new System.Drawing.Point(179, 711);
            this.sizeBtn.Name = "sizeBtn";
            this.sizeBtn.Size = new System.Drawing.Size(155, 59);
            this.sizeBtn.TabIndex = 10;
            this.sizeBtn.Text = "Растянуть фигуру";
            this.sizeBtn.UseVisualStyleBackColor = true;
            this.sizeBtn.Click += new System.EventHandler(this.sizeBtn_Click);
            // 
            // TBSizeY
            // 
            this.TBSizeY.Location = new System.Drawing.Point(159, 668);
            this.TBSizeY.Name = "TBSizeY";
            this.TBSizeY.Size = new System.Drawing.Size(175, 27);
            this.TBSizeY.TabIndex = 9;
            // 
            // TBSizeX
            // 
            this.TBSizeX.Location = new System.Drawing.Point(159, 621);
            this.TBSizeX.Name = "TBSizeX";
            this.TBSizeX.Size = new System.Drawing.Size(175, 27);
            this.TBSizeX.TabIndex = 8;
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelSize.Location = new System.Drawing.Point(33, 572);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(283, 26);
            this.labelSize.TabIndex = 7;
            this.labelSize.Text = "Сжатие/растяжение фигуры";
            // 
            // turnBtn
            // 
            this.turnBtn.Location = new System.Drawing.Point(159, 466);
            this.turnBtn.Name = "turnBtn";
            this.turnBtn.Size = new System.Drawing.Size(175, 57);
            this.turnBtn.TabIndex = 6;
            this.turnBtn.Text = "Повернуть фигуру";
            this.turnBtn.UseVisualStyleBackColor = true;
            this.turnBtn.Click += new System.EventHandler(this.turnBtn_Click);
            // 
            // TBAngleTurn
            // 
            this.TBAngleTurn.Location = new System.Drawing.Point(159, 414);
            this.TBAngleTurn.Name = "TBAngleTurn";
            this.TBAngleTurn.Size = new System.Drawing.Size(175, 27);
            this.TBAngleTurn.TabIndex = 5;
            // 
            // labelTurnObj
            // 
            this.labelTurnObj.AutoSize = true;
            this.labelTurnObj.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTurnObj.Location = new System.Drawing.Point(64, 365);
            this.labelTurnObj.Name = "labelTurnObj";
            this.labelTurnObj.Size = new System.Drawing.Size(176, 26);
            this.labelTurnObj.TabIndex = 4;
            this.labelTurnObj.Text = "Поворот фигуры";
            // 
            // turnObjBtn
            // 
            this.turnObjBtn.Location = new System.Drawing.Point(159, 257);
            this.turnObjBtn.Name = "turnObjBtn";
            this.turnObjBtn.Size = new System.Drawing.Size(175, 53);
            this.turnObjBtn.TabIndex = 3;
            this.turnObjBtn.Text = "Подвинуть фигуру";
            this.turnObjBtn.UseVisualStyleBackColor = true;
            this.turnObjBtn.Click += new System.EventHandler(this.turnObjBtn_Click);
            // 
            // TBMoveObjY
            // 
            this.TBMoveObjY.Location = new System.Drawing.Point(159, 213);
            this.TBMoveObjY.Name = "TBMoveObjY";
            this.TBMoveObjY.Size = new System.Drawing.Size(175, 27);
            this.TBMoveObjY.TabIndex = 2;
            // 
            // TBMoveObjX
            // 
            this.TBMoveObjX.Location = new System.Drawing.Point(159, 171);
            this.TBMoveObjX.Name = "TBMoveObjX";
            this.TBMoveObjX.Size = new System.Drawing.Size(175, 27);
            this.TBMoveObjX.TabIndex = 1;
            // 
            // labelMoveObj
            // 
            this.labelMoveObj.AutoSize = true;
            this.labelMoveObj.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelMoveObj.Location = new System.Drawing.Point(64, 114);
            this.labelMoveObj.Name = "labelMoveObj";
            this.labelMoveObj.Size = new System.Drawing.Size(191, 26);
            this.labelMoveObj.TabIndex = 0;
            this.labelMoveObj.Text = "Движение фигуры";
            // 
            // PBFigure
            // 
            this.PBFigure.Location = new System.Drawing.Point(347, 1);
            this.PBFigure.Name = "PBFigure";
            this.PBFigure.Size = new System.Drawing.Size(709, 792);
            this.PBFigure.TabIndex = 1;
            this.PBFigure.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 798);
            this.Controls.Add(this.PBFigure);
            this.Controls.Add(this.GBMenu);
            this.Name = "Form1";
            this.Text = "Лабораторная работа №2";
            this.GBMenu.ResumeLayout(false);
            this.GBMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBFigure)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox GBMenu;
        private Button sizeBtn;
        private TextBox TBSizeY;
        private TextBox TBSizeX;
        private Label labelSize;
        private Button turnBtn;
        private TextBox TBAngleTurn;
        private Label labelTurnObj;
        private Button turnObjBtn;
        private TextBox TBMoveObjY;
        private TextBox TBMoveObjX;
        private Label labelMoveObj;
        private PictureBox PBFigure;
        private Button createObjBtn;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button decSizeObjBtn;
    }
}