﻿namespace Lab4
{
    partial class appleTree
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(appleTree));
            this.GBMenu = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.helpBtn = new System.Windows.Forms.Button();
            this.temperatureLabel = new System.Windows.Forms.Label();
            this.weatherCLB = new System.Windows.Forms.CheckedListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tempTB = new System.Windows.Forms.TrackBar();
            this.seasonsLB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.canvas = new System.Windows.Forms.PictureBox();
            this.GBMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempTB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.canvas)).BeginInit();
            this.SuspendLayout();
            // 
            // GBMenu
            // 
            this.GBMenu.Controls.Add(this.label4);
            this.GBMenu.Controls.Add(this.helpBtn);
            this.GBMenu.Controls.Add(this.temperatureLabel);
            this.GBMenu.Controls.Add(this.weatherCLB);
            this.GBMenu.Controls.Add(this.label3);
            this.GBMenu.Controls.Add(this.label2);
            this.GBMenu.Controls.Add(this.tempTB);
            this.GBMenu.Controls.Add(this.seasonsLB);
            this.GBMenu.Controls.Add(this.label1);
            this.GBMenu.Location = new System.Drawing.Point(1, 1);
            this.GBMenu.Name = "GBMenu";
            this.GBMenu.Size = new System.Drawing.Size(410, 1031);
            this.GBMenu.TabIndex = 0;
            this.GBMenu.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(76, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(304, 31);
            this.label4.TabIndex = 8;
            this.label4.Text = "Симулятор жизни яблони";
            // 
            // helpBtn
            // 
            this.helpBtn.BackColor = System.Drawing.SystemColors.Menu;
            this.helpBtn.FlatAppearance.BorderSize = 0;
            this.helpBtn.Image = ((System.Drawing.Image)(resources.GetObject("helpBtn.Image")));
            this.helpBtn.Location = new System.Drawing.Point(11, 26);
            this.helpBtn.Name = "helpBtn";
            this.helpBtn.Size = new System.Drawing.Size(59, 57);
            this.helpBtn.TabIndex = 7;
            this.helpBtn.UseVisualStyleBackColor = false;
            this.helpBtn.Click += new System.EventHandler(this.helpBtn_Click);
            // 
            // temperatureLabel
            // 
            this.temperatureLabel.AutoSize = true;
            this.temperatureLabel.Location = new System.Drawing.Point(180, 897);
            this.temperatureLabel.Name = "temperatureLabel";
            this.temperatureLabel.Size = new System.Drawing.Size(0, 20);
            this.temperatureLabel.TabIndex = 6;
            // 
            // weatherCLB
            // 
            this.weatherCLB.FormattingEnabled = true;
            this.weatherCLB.Location = new System.Drawing.Point(46, 517);
            this.weatherCLB.Name = "weatherCLB";
            this.weatherCLB.Size = new System.Drawing.Size(313, 114);
            this.weatherCLB.TabIndex = 5;
            this.weatherCLB.SelectedIndexChanged += new System.EventHandler(this.weatherCLB_ItemCheck);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(46, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(294, 82);
            this.label3.TabIndex = 4;
            this.label3.Text = "Выберите погодные\r\n          условия:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(31, 792);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(342, 41);
            this.label2.TabIndex = 3;
            this.label2.Text = "Выберите температуру:";
            // 
            // tempTB
            // 
            this.tempTB.Location = new System.Drawing.Point(46, 850);
            this.tempTB.Name = "tempTB";
            this.tempTB.Size = new System.Drawing.Size(313, 56);
            this.tempTB.TabIndex = 2;
            this.tempTB.Scroll += new System.EventHandler(this.tempTB_ValueChanged);
            // 
            // seasonsLB
            // 
            this.seasonsLB.FormattingEnabled = true;
            this.seasonsLB.ItemHeight = 20;
            this.seasonsLB.Location = new System.Drawing.Point(46, 164);
            this.seasonsLB.Name = "seasonsLB";
            this.seasonsLB.Size = new System.Drawing.Size(313, 104);
            this.seasonsLB.TabIndex = 1;
            this.seasonsLB.SelectedIndexChanged += new System.EventHandler(this.seasonsLB_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(46, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Выберите сезон года:";
            // 
            // canvas
            // 
            this.canvas.Location = new System.Drawing.Point(417, 12);
            this.canvas.Name = "canvas";
            this.canvas.Size = new System.Drawing.Size(1473, 1020);
            this.canvas.TabIndex = 1;
            this.canvas.TabStop = false;
            // 
            // appleTree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.canvas);
            this.Controls.Add(this.GBMenu);
            this.Name = "appleTree";
            this.Text = "Яблоня";
            this.GBMenu.ResumeLayout(false);
            this.GBMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempTB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.canvas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox GBMenu;
        private ListBox seasonsLB;
        private Label label1;
        private CheckedListBox weatherCLB;
        private Label label3;
        private Label label2;
        private TrackBar tempTB;
        private PictureBox canvas;
        private Label temperatureLabel;
        private Button helpBtn;
        private Label label4;
    }
}