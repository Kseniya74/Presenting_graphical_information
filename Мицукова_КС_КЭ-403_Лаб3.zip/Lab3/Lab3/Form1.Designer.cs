﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PBFigure = new System.Windows.Forms.PictureBox();
            this.createObjBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.seedBtn = new System.Windows.Forms.Button();
            this.scanBtn = new System.Windows.Forms.Button();
            this.CDBtn = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.deleteObjBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PBFigure)).BeginInit();
            this.SuspendLayout();
            // 
            // PBFigure
            // 
            this.PBFigure.Location = new System.Drawing.Point(236, 0);
            this.PBFigure.Name = "PBFigure";
            this.PBFigure.Size = new System.Drawing.Size(708, 584);
            this.PBFigure.TabIndex = 0;
            this.PBFigure.TabStop = false;
            // 
            // createObjBtn
            // 
            this.createObjBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.createObjBtn.Location = new System.Drawing.Point(31, 173);
            this.createObjBtn.Name = "createObjBtn";
            this.createObjBtn.Size = new System.Drawing.Size(191, 57);
            this.createObjBtn.TabIndex = 12;
            this.createObjBtn.Text = "Создать\r\nновую фигуру";
            this.createObjBtn.UseVisualStyleBackColor = true;
            this.createObjBtn.Click += new System.EventHandler(this.createObjBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(43, 558);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "Выбор заливки:";
            // 
            // seedBtn
            // 
            this.seedBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seedBtn.Location = new System.Drawing.Point(30, 587);
            this.seedBtn.Name = "seedBtn";
            this.seedBtn.Size = new System.Drawing.Size(191, 57);
            this.seedBtn.TabIndex = 14;
            this.seedBtn.Text = "Заливка затравкой";
            this.seedBtn.UseVisualStyleBackColor = true;
            this.seedBtn.Click += new System.EventHandler(this.seedBtn_Click);
            // 
            // scanBtn
            // 
            this.scanBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.scanBtn.Location = new System.Drawing.Point(30, 650);
            this.scanBtn.Name = "scanBtn";
            this.scanBtn.Size = new System.Drawing.Size(191, 57);
            this.scanBtn.TabIndex = 15;
            this.scanBtn.Text = "Построчное сканирование";
            this.scanBtn.UseVisualStyleBackColor = true;
            this.scanBtn.Click += new System.EventHandler(this.scanBtn_Click);
            // 
            // CDBtn
            // 
            this.CDBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CDBtn.Location = new System.Drawing.Point(30, 384);
            this.CDBtn.Name = "CDBtn";
            this.CDBtn.Size = new System.Drawing.Size(191, 57);
            this.CDBtn.TabIndex = 16;
            this.CDBtn.Text = "Выбрать цвет";
            this.CDBtn.UseVisualStyleBackColor = true;
            this.CDBtn.Click += new System.EventHandler(this.CDBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(54, 355);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 26);
            this.label2.TabIndex = 17;
            this.label2.Text = "Выбор цвета:";
            // 
            // deleteObjBtn
            // 
            this.deleteObjBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.deleteObjBtn.Location = new System.Drawing.Point(31, 902);
            this.deleteObjBtn.Name = "deleteObjBtn";
            this.deleteObjBtn.Size = new System.Drawing.Size(191, 57);
            this.deleteObjBtn.TabIndex = 18;
            this.deleteObjBtn.Text = "Удалить фигуру";
            this.deleteObjBtn.UseVisualStyleBackColor = true;
            this.deleteObjBtn.Click += new System.EventHandler(this.deleteObjBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(22, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 52);
            this.label3.TabIndex = 19;
            this.label3.Text = "Закраска замкнутых\r\n         контуров";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.deleteObjBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CDBtn);
            this.Controls.Add(this.scanBtn);
            this.Controls.Add(this.seedBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.createObjBtn);
            this.Controls.Add(this.PBFigure);
            this.Name = "Form1";
            this.Text = "Лабораторная работа №3";
            ((System.ComponentModel.ISupportInitialize)(this.PBFigure)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox PBFigure;
        private Button createObjBtn;
        private Label label1;
        private Button seedBtn;
        private Button scanBtn;
        private Button CDBtn;
        private ColorDialog colorDialog1;
        private Label label2;
        private Button deleteObjBtn;
        private Label label3;
    }
}